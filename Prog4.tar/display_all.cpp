#include "activity.h"
// constructor fot trip class
trip::trip()
{
	name = NULL;//initialize name pointer 
	location = NULL;// initialize location pointer 
	description = NULL;//initialize description pointer
	afterthought = NULL; // initialize afterthought pointer
	supplies = NULL;//initialize supplies pointer
	dates = NULL;//initialze dates pointer
}
//Destructor for trip class
trip::~trip()
{
	if(name)
	{
		delete[]name;//deallocate name pointer
	}
	if(location)
	{
		delete[]location;//deallocate location pointer
	}
	if(description)
	{
		delete[]description;//deallocation description pointer
	}
	if (afterthought)
	{
		delete[]afterthought;// deallocate afterthought pointer
	}
	if(supplies)
	{
		delete[]supplies;//deallocate supplies pointer
	}
	if(dates)
	{
		delete[]dates;//deallocate dates pointer
	}
}
//Constructor for storage class
storage::storage()
{
	size_array = 10; // set size_array to 10
	arr =new trip [size_array]; // points to an array for a trip array
	number_items = 0; // initialize number_items
}
//Desctructor for storage class
storage::~storage()
{
	if(arr)
	{
		delete[]arr;//deallocate arr pointer
	}
}
void trip::display_one()
{
	cout<<"Name of the Activity: " <<name<<endl;
	cout<<"Location of the Activity: "<<location<<endl;
	cout<<"Description of the Activity: "<<description<<endl;
	cout<<"Afterthought of the Activity: "<<afterthought<<endl;
	cout<<"Supplies of the Activity: "<<supplies<<endl;
	cout<< "Date of the Activity: "<<dates<<endl<<endl;
}

void storage::display_all()
{
	if (number_items == 0) // if there is no activity that was stored
	{
		cout<<"There is no activity to display."<<endl; // Prompt user that there is no activity
	}
	else
	{
		for(int i=0; i<number_items; ++i) // increment how many number of items there are
		{
			arr[i].display_one();// display one activity at a time
		}
	}
}
