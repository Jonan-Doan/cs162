#include "activity.h"
bool trip::compare_subject(char to_compare[])
{
	if (strcmp(to_compare,name)==0) //if there is a match
	{
		return true;// Yes!!! match
	}
	else
	{
		return false;//No!!! not a match
	}
}
void storage::display_matching()
{
	char response[ACTIVITY_SIZE]; // create an array that holds the user response
	bool check_matching=false; // create a bool variable that check if there is a match
	if (number_items == 0)// if there is no items currently availaible
	{
		cout<<"There is no activity to display."<<endl;
	}
	else
	{
		cout<<"Please type in specific activity that you want to search for."<<endl;
		cin.get(response,ACTIVITY_SIZE, '\n');// store the user response of what particular activity they want to search for
		cin.ignore(100, '\n');
		for (int i=0; i<number_items; ++i) // increment until it reach the max number of items
		{
			if (arr[i].compare_subject(response)== true) // if there is a match
			{
				arr[i].display_one(); // display that particular activity
				check_matching=true; // set check_mathing to true in order to indicate there is a match
			}	
		}
		if (check_matching==false) // if the activity they are looking for was not stored
		{
			cout<<"The activity you are looking for is currently unavailable."<<endl;
		}
	}
}
