#include "activity.h"

int main()
{
	char choice; // gives the user a choics if they want to add a new item to the list, search for a matching activity, display all of the activity, or quit
	storage activities; // object for the storage class
	do
	{
		cout<<"Press A if you want to add a new item to the list, S if you want to search for a matching activity,"
		<<endl<<"D if you want to display all of the activity,and Q if you want to quit."<<endl;
		cin>>choice;
		cin.ignore(100, '\n');
		choice=toupper(choice); // capitalize the letter that the user had typed in
		if (choice =='A')// If they want to add a new item to the list	
		{
			activities.read_activity();
		}
		if(choice =='S') // If they want to search for a particular activity
		{
			activities.display_matching();
		}
		if(choice=='D') // if they want to display all of the activity
		{
			activities.display_all();
		}
	}while(choice != 'Q');// end program once user had type q
	return 0;
}
