//Jonan Doan
//CS162
//March 2,2020
//
//Program Purpose; This program allows the user to have the opion read in a new activity, search for a particular activity, 
//display all of the activity, or to quit from the program. If the user want to read in a new activity, the program will read each individual activities with all of
//its information. If the user want to search for a particular activity, the program will search for that particular activity and display the activitty with all of 
//its content. If the user want to display all of the activity, the program will display all of the stored activity with all of its content. If the user want to
//quit, the program will end.
#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;
const int ACTIVITY_SIZE = 40;// create constant size for the name of the activity
const int LOCATION_SIZE = 30; // create a constant size for the name of the location that the activity occur.
const int DESCRIPTION_SIZE = 130;// create a constant size for the description of the activity.
const int AFTERTHOUGHT_SIZE = 200;// create a constant size for the afterthought of the activity.
const int SUPPLIES_SIZE = 35; // create a constant size for what supplies is needed for the activity
const int DATES_SIZE = 30; // create a constant size for the date of when the activity occur.

class trip
{
public:
	trip(); // constructor
	~trip(); // destructor
	void get_activity(); // function allows the program to read the name, location, description, aftethought, supplies, and dates of the activity
	void display_one(); // function allows the program to display one activity with all of its information 
	bool compare_subject(char to_compare[]); // function allows the program to compare what the user is searching for with the activity and check if they match
private:
	char *name; //pointer that stores the name of the activity
	char *location; // Pointers that stores the location of the activity
	char *description; // pointers that stores the description of the activity
	char *afterthought; // pointers that stores the afterthoughts of the activity
	char *supplies; // pointers that stores the supplies of the activity
	char *dates; // pointers that stores the dates of when the activity occur
};
class storage
{
public:
	storage(); // constructor
	~storage(); // destructor
	void read_activity(); // function allows the program to read in each individual activity with all of its information.
	void display_all(); // function allows the program to display all of the activity that was read in.
	void display_matching(); // function allows the program to display the matching activity the user is trying to search for.
private:
	trip *arr; // pointers that holds all individual activity
	int number_items = 0; // allows the program to determine how many activity are there curently
	int size_array = 10; //the size of the array once it is allocated 
};
