#include "activity.h"
void trip::get_activity()
{
	char name_temp[ACTIVITY_SIZE];// temporary aray for name
	char location_temp[LOCATION_SIZE]; //temporary arry for location
	char description_temp[DESCRIPTION_SIZE]; //temporary aray for description
	char afterthought_temp[AFTERTHOUGHT_SIZE]; // temporary array for the afterthought
	char supplies_temp[SUPPLIES_SIZE]; //temporarty array for the supplies
	char dates_temp[DATES_SIZE]; //temporrary array for the dates
	if(name)
	{
		delete[]name; // deallocate name pointer
	}
	if(location)
	{
		delete[]location; // deallocate location pointer
	}
	if(description)
	{
		delete[]description; // deallocate description pointer
	}
	if (afterthought)
	{
		delete[]afterthought; // deallocate afterthought pointer
	}
	if(supplies)
	{
		delete[]supplies; // deallocate supplies pointer
	}
	if(dates)
	{
		delete[]dates; //deallocate dates pointer
	}
	//Prompt user to type in the name of the activity for the particular activity and store it into a dynamic array
	//
	
	cout<<"Please type in the name of the activity."<<endl;
	cin.get(name_temp, ACTIVITY_SIZE, '\n');
	cin.ignore(100, '\n');
	name= new char[strlen(name_temp)+1];
	strcpy(name,name_temp);

		
	//Prompt user to type in the location of the activity for the particular activity and store it into a dynamic array
	//

	cout<<"Please type in the location of the activity."<<endl;
	cin.get(location_temp, LOCATION_SIZE, '\n');
	cin.ignore(100, '\n');
	location= new char[strlen(location_temp)+1];
	strcpy(location,location_temp);


	//Prompt user to type in the description of the activity for the particular activity and store it into a dynamic array
	//
	
	cout<<"Please type in the description of the activity."<<endl;
	cin.get(description_temp, DESCRIPTION_SIZE, '\n');
	cin.ignore(100, '\n');
	description= new char[strlen(description_temp)+1];
	strcpy(description,description_temp);

	
	//Prompt user to type in the afterthought of the activity for the particular activity and store it into a dynamic array
	//
	
	cout<<"Please type in the afterthought of the activity."<<endl;
	cin.get(afterthought_temp, AFTERTHOUGHT_SIZE, '\n');
	cin.ignore(100, '\n');
	afterthought= new char[strlen(afterthought_temp)+1];
	strcpy(afterthought,afterthought_temp);


	//Prompt user to type in the supplies of the activity for the particular activity and store it into a dynamic array
	//
	
	cout<<"Please type in the supplies of the activity."<<endl;
	cin.get(supplies_temp, SUPPLIES_SIZE, '\n');
	cin.ignore(100, '\n');
	supplies= new char[strlen(supplies_temp)+1];
	strcpy(supplies,supplies_temp);

	
	//Prompt user to type in the dates of the activity for the particular activity and store it into a dynamic array
	//
	
	cout<<"Please type in the dates that the activity occur."<<endl;
	cin.get(dates_temp, DATES_SIZE, '\n');
	cin.ignore(100, '\n');
	dates= new char[strlen(dates_temp)+1];
	strcpy(dates,dates_temp);
}
void storage::read_activity()
{
	arr[number_items].get_activity(); //store new ativities
	++number_items; // increment the number of items
}
